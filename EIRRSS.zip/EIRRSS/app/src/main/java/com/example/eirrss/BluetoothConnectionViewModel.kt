package com.example.eirrss

import android.arch.lifecycle.ViewModel

class BluetoothConnectionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}