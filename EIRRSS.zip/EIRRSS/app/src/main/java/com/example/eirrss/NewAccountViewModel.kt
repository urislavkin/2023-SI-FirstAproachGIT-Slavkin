package com.example.eirrss

import android.arch.lifecycle.ViewModel

class NewAccountViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}