package com.example.eirrss

import androidx.lifecycle.ViewModel

class NewAccountViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}