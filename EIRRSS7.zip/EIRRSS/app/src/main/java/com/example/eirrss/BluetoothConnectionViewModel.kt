package com.example.eirrss

import androidx.lifecycle.ViewModel

class BluetoothConnectionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}