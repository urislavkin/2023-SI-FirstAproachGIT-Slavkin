package com.example.eirrss

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider

class forgot_password : Fragment() {

    companion object {
        fun newInstance() = forgot_password()
    }

    private lateinit var viewModel: ForgotPasswordViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_forgot_password, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            ForgotPasswordViewModel::class.java
        )
        // TODO: Use the ViewModel
    }

}

private fun ViewModelProvider.get(modelClass: Class<ForgotPasswordViewModel>): ForgotPasswordViewModel {

    return TODO("Provide the return value")
}
